# src/core/cache.py
import json
from typing import Any, Optional, Union, Dict
from redis import Redis
from ..core.config import settings

redis_client = Redis(
    host=settings.REDIS_HOST,
    port=settings.REDIS_PORT,
    db=0,
    password=settings.REDIS_PASSWORD,
    decode_responses=True  # Para trabajar con strings en lugar de bytes
)

def get_cache_key(prefix: str, *args, **kwargs) -> str:
    """Genera una clave de caché a partir de un prefijo y parámetros"""
    key_parts = [prefix]
    
    # Añadir args
    for arg in args:
        key_parts.append(str(arg))
        
    # Añadir kwargs ordenados
    if kwargs:
        sorted_kwargs = sorted(kwargs.items())
        for k, v in sorted_kwargs:
            key_parts.append(f"{k}={v}")
            
    return ":".join(key_parts)

def get_from_cache(key: str) -> Optional[Any]:
    """Obtiene un valor de la caché, deserializado de JSON"""
    value = redis_client.get(key)
    if value:
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    return None

def set_in_cache(key: str, value: Any, expire_seconds: int = 3600) -> bool:
    """Almacena un valor en la caché, serializado a JSON"""
    try:
        json_value = json.dumps(value)
        return redis_client.set(key, json_value, ex=expire_seconds)
    except (TypeError, json.JSONEncodeError):
        return False

def delete_from_cache(key: str) -> int:
    """Elimina una clave de la caché"""
    return redis_client.delete(key)

def delete_pattern(pattern: str) -> int:
    """Elimina todas las claves que coincidan con un patrón"""
    keys = redis_client.keys(pattern)
    if keys:
        return redis_client.delete(*keys)
    return 0

def invalidate_product_cache(product_id: Optional[int] = None):
    """Invalida la caché relacionada con productos"""
    patterns = []
    
    if product_id:
        # Invalidar solo cachés de este producto
        patterns = [
            f"product:{product_id}:*",
            f"products:*:ids:*{product_id}*",
            "products:recent",
            "products:popular"
        ]
    else:
        # Invalidar todas las cachés de productos
        patterns = [
            "product:*",
            "products:*"
        ]
        
    for pattern in patterns:
        delete_pattern(pattern)