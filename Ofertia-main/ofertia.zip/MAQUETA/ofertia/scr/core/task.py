# src/core/tasks.py
from celery import Celery
from celery.schedules import crontab
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from ..scrapers.spiders.falabella import FalabellaSpider
from ..scrapers.spiders.exito import ExitoSpider
from ..scrapers.spiders.homecenter import HomecenterSpider
# Más importaciones...

app = Celery('ofertia', broker='pyamqp://guest@localhost//')

# Configurar tareas periódicas
app.conf.beat_schedule = {
    'scrape-falabella-every-day': {
        'task': 'src.core.tasks.run_falabella_spider',
        'schedule': crontab(hour=1, minute=0),  # 1:00 AM
    },
    'scrape-exito-every-day': {
        'task': 'src.core.tasks.run_exito_spider',
        'schedule': crontab(hour=2, minute=0),  # 2:00 AM
    },
    'scrape-homecenter-every-day': {
        'task': 'src.core.tasks.run_homecenter_spider',
        'schedule': crontab(hour=3, minute=0),  # 3:00 AM
    },
    # Más tiendas...
}

@app.task
def run_falabella_spider():
    """Ejecuta el spider de Falabella y procesa los resultados"""
    settings = get_project_settings()
    process = CrawlerProcess(settings)
    process.crawl(FalabellaSpider)
    process.start()  # El proceso bloqueará hasta que termine el scraping
    
    # Registrar en log
    return 'Falabella spider completed'

# Tareas similares para otras tiendas...

@app.task
def check_scraping_results():
    """Verificar los resultados del scraping y generar alertas si es necesario"""
    # Lógica para verificar calidad/cantidad de datos
    # Enviar alertas si hay problemas