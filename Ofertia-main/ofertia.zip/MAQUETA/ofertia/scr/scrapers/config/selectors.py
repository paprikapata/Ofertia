# src/scrapers/config/selectors.py
STORE_SELECTORS = {
    'falabella': {
        'product_container': 'div.product-card',
        'name': 'div.product-name::text',
        'price': 'div.product-price::text',
        'image': 'img::attr(src)',
        'link': 'a::attr(href)',
        'sku': 'span.product-sku::text'
    },
    'exito': {
        'product_container': 'div.product-tile',
        'name': 'h2.product-name::text',
        'price': 'span.price::text',
        'image': 'img.tile-image::attr(src)',
        'link': 'a.product-link::attr(href)',
        'sku': 'div.product-sku::text'
    },
    # Más tiendas...
}