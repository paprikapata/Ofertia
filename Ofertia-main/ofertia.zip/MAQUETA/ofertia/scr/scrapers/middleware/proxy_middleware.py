# src/scrapers/middleware/proxy_middleware.py
import random
from scrapy import signals

class RotatingProxyMiddleware:
    def __init__(self, proxy_list):
        self.proxy_list = proxy_list
        
    @classmethod
    def from_crawler(cls, crawler):
        proxy_list = crawler.settings.get('PROXY_LIST', [])
        if not proxy_list:
            # Cargar desde archivo o servicio externo
            with open('proxies.txt', 'r') as f:
                proxy_list = [line.strip() for line in f]
        
        middleware = cls(proxy_list)
        return middleware
    
    def process_request(self, request, spider):
        # No usar proxy para ciertas solicitudes
        if 'no_proxy' in request.meta:
            return None
            
        # Asignar proxy aleatorio
        request.meta['proxy'] = random.choice(self.proxy_list)
        return None