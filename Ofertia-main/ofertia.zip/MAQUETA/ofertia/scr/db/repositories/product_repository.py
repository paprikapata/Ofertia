# src/db/repositories/product_repository.py
from sqlalchemy.orm import Session
from sqlalchemy import func, asc, desc
from ..models import Product, Store, Category, ProductCategory
from ...api.models.product import ProductCreate, ProductUpdate

class ProductRepository:
    def __init__(self, db: Session):
        self.db = db
        
    def create(self, product_data: ProductCreate):
        """Crear un nuevo producto"""
        db_product = Product(
            name=product_data.name,
            normalized_name=self._normalize_name(product_data.name),
            description=product_data.description,
            brand=product_data.brand,
            model=product_data.model,
            store_id=product_data.store_id,
            store_sku=product_data.store_sku,
            url=product_data.url,
            image_url=product_data.image_url,
            current_price=product_data.current_price,
            rating=product_data.rating,
            review_count=product_data.review_count,
            in_stock=product_data.in_stock
        )
        self.db.add(db_product)
        self.db.commit()
        self.db.refresh(db_product)
        
        # Añadir categorías si se especifican
        if product_data.category_ids:
            for category_id in product_data.category_ids:
                product_category = ProductCategory(
                    product_id=db_product.id,
                    category_id=category_id,
                    is_primary=category_id == product_data.primary_category_id
                )
                self.db.add(product_category)
            self.db.commit()
            
        return db_product
        
    def get(self, product_id: int):
        """Obtener un producto por ID"""
        return self.db.query(Product).filter(Product.id == product_id).first()
        
    def update(self, product_id: int, product_data: ProductUpdate):
        """Actualizar un producto existente"""
        db_product = self.get(product_id)
        
        # Actualizar solo los campos proporcionados
        update_data = product_data.dict(exclude_unset=True)
        
        # Si el nombre se actualiza, actualizar también el nombre normalizado
        if "name" in update_data:
            update_data["normalized_name"] = self._normalize_name(update_data["name"])
            
        for key, value in update_data.items():
            setattr(db_product, key, value)
            
        self.db.commit()
        self.db.refresh(db_product)
        return db_product
        
    def delete(self, product_id: int):
        """Eliminar un producto (soft delete)"""
        # En este ejemplo usamos borrado real, pero podría implementarse
        # un soft delete con una columna is_deleted
        db_product = self.get(product_id)
        self.db.delete(db_product)
        self.db.commit()
        
    def list(
        self,
        skip: int = 0,
        limit: int = 100,
        search: str = None,
        min_price: float = None,
        max_price: float = None,
        store_id: int = None,
        category_id: int = None,
        in_stock: bool = None,
        sort_by: str = "current_price",
        sort_order: str = "asc"
    ):
        """Listar productos con filtros y ordenamiento"""
        query = self.db.query(Product)
        
        # Aplicar filtros
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                Product.name.ilike(search_term) | 
                Product.description.ilike(search_term) |
                Product.brand.ilike(search_term)
            )
            
        if min_price is not None:
            query = query.filter(Product.current_price >= min_price)
            
        if max_price is not None:
            query = query.filter(Product.current_price <= max_price)
            
        if store_id:
            query = query.filter(Product.store_id == store_id)
            
        if category_id:
            query = query.join(ProductCategory).filter(
                ProductCategory.category_id == category_id
            )
            
        if in_stock is not None:
            query = query.filter(Product.in_stock == in_stock)
            
        # Aplicar ordenamiento
        order_func = asc if sort_order.lower() == "asc" else desc
        
        if sort_by == "name":
            query = query.order_by(order_func(Product.name))
        elif sort_by == "current_price":
            query = query.order_by(order_func(Product.current_price))
        elif sort_by == "rating":
            query = query.order_by(order_func(Product.rating))
        elif sort_by == "last_updated":
            query = query.order_by(order_func(Product.last_updated))
        else:
            # Por defecto ordenar por precio
            query = query.order_by(order_func(Product.current_price))
            
        # Paginación
        return query.offset(skip).limit(limit).all()
        
    def _normalize_name(self, name: str) -> str:
        """Normaliza el nombre del producto para búsquedas y comparaciones"""
        import re
        name = name.lower()
        name = re.sub(r'[^\w\s]', '', name)  # Eliminar caracteres especiales
        name = re.sub(r'\s+', ' ', name)     # Normalizar espacios
        return name.strip()
# src/db/repositories/product_repository.py (optimizado)
from sqlalchemy.orm import Session, joinedload, contains_eager
from sqlalchemy import func, desc, asc, and_, or_, text
from ..models import Product, Store, Price, Category, ProductCategory, ProductSpecification
from typing import List, Optional, Dict, Any
import datetime

class ProductRepository:
    def __init__(self, db: Session):
        self.db = db
        
    def get(self, product_id: int):
        """Obtener un producto por ID con carga optimizada"""
        return self.db.query(Product).options(
            joinedload(Product.store),
            joinedload(Product.categories).joinedload(ProductCategory.category),
            joinedload(Product.specifications)
        ).filter(Product.id == product_id).first()
        
    def search(
        self,
        search: Optional[str] = None,
        category_id: Optional[int] = None,
        min_price: Optional[float] = None,
        max_price: Optional[float] = None,
        store_ids: Optional[List[int]] = None,
        brands: Optional[List[str]] = None,
        in_stock: Optional[bool] = None,
        sort_by: str = "current_price",
        sort_order: str = "asc",
        skip: int = 0,
        limit: int = 20
    ):
        """Búsqueda optimizada de productos"""
        # Consulta base con precarga de relaciones
        query = self.db.query(Product).options(
            joinedload(Product.store)
        ).filter(Product.is_deleted == False)
        
        # Filtro de texto (búsqueda por nombre y descripción)
        if search:
            search_terms = search.split()
            search_filters = []
            
            for term in search_terms:
                term_filter = or_(
                    Product.name.ilike(f"%{term}%"),
                    Product.normalized_name.ilike(f"%{term}%"),
                    Product.description.ilike(f"%{term}%"),
                    Product.brand.ilike(f"%{term}%"),
                    Product.model.ilike(f"%{term}%")
                )
                search_filters.append(term_filter)
                
            # Combinar todos los términos con AND
            if search_filters:
                query = query.filter(and_(*search_filters))
                
        # Filtro por categoría
        if category_id:
            query = query.join(
                ProductCategory, 
                ProductCategory.product_id == Product.id
            ).filter(ProductCategory.category_id == category_id)
            
        # Filtro por precio
        if min_price is not None:
            query = query.filter(Product.current_price >= min_price)
            
        if max_price is not None:
            query = query.filter(Product.current_price <= max_price)
            
        # Filtro por tiendas
        if store_ids:
            query = query.filter(Product.store_id.in_(store_ids))
            
        # Filtro por marcas
        if brands:
            query = query.filter(Product.brand.in_(brands))
            
        # Filtro por disponibilidad
        if in_stock is not None:
            query = query.filter(Product.in_stock == in_stock)
            
        # Ordenamiento
        order_func = asc if sort_order.lower() == "asc" else desc
        
        if sort_by == "name":
            query = query.order_by(order_func(Product.name))
        elif sort_by == "current_price":
            query = query.order_by(order_func(Product.current_price))
        elif sort_by == "rating":
            query = query.order_by(order_func(Product.rating))
        elif sort_by == "last_updated":
            query = query.order_by(order_func(Product.last_updated))
        else:
            query = query.order_by(order_func(Product.current_price))
            
        # Paginación optimizada
        total = query.count()
        results = query.offset(skip).limit(limit).all()
        
        return {
            "items": results,
            "total": total,
            "page": skip // limit + 1 if limit > 0 else 1,
            "pages": (total + limit - 1) // limit if limit > 0 else 1,
            "limit": limit
        }
        
    def get_price_history(self, product_id: int, days: int = 30):
        """Obtener historial de precios de un producto"""
        # Calcular fecha límite
        start_date = datetime.datetime.now() - datetime.timedelta(days=days)
        
        # Consulta optimizada
        query = self.db.query(
            Price.timestamp.label('date'),
            Price.amount.label('price'),
            Store.name.label('store_name'),
            Store.id.label('store_id')
        ).join(
            Store, Price.store_id == Store.id
        ).filter(
            Price.product_id == product_id,
            Price.timestamp >= start_date
        ).order_by(
            Store.id,
            Price.timestamp
        )
        
        results = query.all()
        
        # Estructurar datos para gráfico
        stores = {}
        dates = set()
        
        for result in results:
            store_id = result.store_id
            date_str = result.date.strftime('%Y-%m-%d')
            dates.add(date_str)
            
            if store_id not in stores:
                                stores[store_id] = {
                    'name': result.store_name,
                    'prices': {}
                }
                
            stores[store_id]['prices'][date_str] = result.price
            
        # Convertir a formato de serie temporal
        date_list = sorted(list(dates))
        series = []
        
        for store_id, store_data in stores.items():
            data_points = []
            
            for date in date_list:
                price = store_data['prices'].get(date, None)
                if price is not None:
                    data_points.append({
                        'x': date,
                        'y': price
                    })
                    
            series.append({
                'name': store_data['name'],
                'data': data_points
            })
            
        return {
            'dates': date_list,
            'series': series
        }
        
    def get_product_statistics(self, product_id: int):
        """Obtener estadísticas de precio para un producto"""
        # Consulta para obtener mínimo, máximo, promedio de precios
        stats_query = self.db.query(
            func.min(Price.amount).label('min_price'),
            func.max(Price.amount).label('max_price'),
            func.avg(Price.amount).label('avg_price'),
            func.count(Price.id).label('price_count')
        ).filter(
            Price.product_id == product_id,
            Price.amount > 0  # Excluir precios 0
        )
        
        stats = stats_query.first()
        
        # Obtener tienda con precio más bajo actualmente
        best_store_query = self.db.query(
            Store.id,
            Store.name,
            Price.amount
        ).join(
            Store, Price.store_id == Store.id
        ).filter(
            Price.product_id == product_id,
            Price.is_available == True
        ).order_by(
            Price.amount.asc()
        ).limit(1)
        
        best_store = best_store_query.first()
        
        return {
            'min_price': stats.min_price if stats.price_count > 0 else None,
            'max_price': stats.max_price if stats.price_count > 0 else None,
            'avg_price': float(stats.avg_price) if stats.price_count > 0 else None,
            'price_count': stats.price_count,
            'best_store': {
                'id': best_store.id,
                'name': best_store.name,
                'price': best_store.amount
            } if best_store else None
        }
        
    def find_similar(self, product, limit=5):
        """Encontrar productos similares (optimizado con ranking de similitud)"""
        # Extraer palabras clave del nombre
        name_words = set(product.normalized_name.lower().split())
        
        # Excluir palabras comunes que no aportan significado
        stop_words = {'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 'y', 'o', 'de', 'del', 'a', 'con', 'por', 'para'}
        name_words = name_words - stop_words
        
        # Filtrar por la misma marca si está disponible
        base_query = self.db.query(
            Product,
            func.count(text('1')).label('match_count')
        ).filter(
            Product.id != product.id,  # Excluir el producto actual
            Product.is_deleted == False
        )
        
        # Si tiene marca, dar prioridad a productos de la misma marca
        if product.brand:
            base_query = base_query.filter(Product.brand == product.brand)
            
        # Filtrar por palabras clave en el nombre
        conditions = []
        for word in name_words:
            if len(word) >= 3:  # Ignorar palabras muy cortas
                conditions.append(Product.normalized_name.ilike(f'%{word}%'))
                
        if conditions:
            base_query = base_query.filter(or_(*conditions))
            
            # Agrupar por producto y ordenar por cantidad de coincidencias
            base_query = base_query.group_by(Product.id).order_by(
                desc('match_count'),
                asc(Product.current_price)
            )
        else:
            # Si no hay palabras clave válidas, ordenar por marca y precio
            base_query = base_query.order_by(
                desc(Product.brand == product.brand),
                asc(Product.current_price)
            )
        
        # Limitar resultados    
        return base_query.limit(limit).all()
        
    def get_best_price_by_name(self, product_name: str):
        """Obtener el mejor precio para un producto por nombre"""
        # Normalizar nombre de búsqueda
        normalized_name = self._normalize_name(product_name)
        
        # Buscar productos que coincidan con el nombre
        products_query = self.db.query(
            Product.id,
            Product.name,
            Product.brand,
            Product.current_price,
            Product.image_url,
            Store.name.label('store_name'),
            Store.id.label('store_id')
        ).join(
            Store, Product.store_id == Store.id
        ).filter(
            Product.normalized_name.ilike(f'%{normalized_name}%'),
            Product.is_deleted == False,
            Product.in_stock == True
        ).order_by(
            Product.current_price.asc()
        )
        
        products = products_query.limit(10).all()
        
        # Agrupar por tienda para mostrar el mejor precio en cada una
        stores = {}
        for product in products:
            if product.store_id not in stores or product.current_price < stores[product.store_id]['price']:
                stores[product.store_id] = {
                    'product_id': product.id,
                    'product_name': product.name,
                    'brand': product.brand,
                    'price': product.current_price,
                    'image_url': product.image_url,
                    'store_id': product.store_id,
                    'store_name': product.store_name
                }
                
        # Convertir a lista ordenada por precio
        result = list(stores.values())
        result.sort(key=lambda x: x['price'])
        
        return result
        
    def _normalize_name(self, name: str) -> str:
        """Normaliza el nombre del producto para búsquedas y comparaciones"""
        import re
        if not name:
            return ""
            
        name = name.lower()
        name = re.sub(r'[^\w\s]', '', name)  # Eliminar caracteres especiales
        name = re.sub(r'\s+', ' ', name)     # Normalizar espacios
        return name.strip()
                