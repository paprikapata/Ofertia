# src/api/routes/admin.py
from fastapi import APIRouter, Depends, HTTPException, Query, Path
from sqlalchemy.orm import Session
from typing import List, Optional
from ..models.store import StoreCreate, StoreUpdate, StoreResponse
from ..models.category import CategoryCreate, CategoryUpdate, CategoryResponse
from ..models.product import ProductCreate, ProductUpdate, ProductResponse
from ...db.session import get_db
from ...db.repositories.store_repository import StoreRepository
from ...db.repositories.category_repository import CategoryRepository
from ...db.repositories.product_repository import ProductRepository
from ...core.security import get_admin_user

router = APIRouter(prefix="/admin", dependencies=[Depends(get_admin_user)])

# Rutas para gestión de tiendas
@router.post("/stores", response_model=StoreResponse)
def create_store(
    store: StoreCreate,
    db: Session = Depends(get_db)
):
    """Crear una nueva tienda (solo administradores)"""
    repository = StoreRepository(db)
    return repository.create(store)

@router.get("/stores", response_model=List[StoreResponse])
def list_stores(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Listar todas las tiendas (solo administradores)"""
    repository = StoreRepository(db)
    return repository.list(skip=skip, limit=limit)

@router.get("/stores/{store_id}", response_model=StoreResponse)
def get_store(
    store_id: int = Path(..., title="ID de la tienda"),
    db: Session = Depends(get_db)
):
    """Obtener detalle de una tienda (solo administradores)"""
    repository = StoreRepository(db)
    store = repository.get(store_id)
    if not store:
        raise HTTPException(status_code=404, detail="Tienda no encontrada")
    return store

@router.put("/stores/{store_id}", response_model=StoreResponse)
def update_store(
    store_data: StoreUpdate,
    store_id: int = Path(..., title="ID de la tienda"),
    db: Session = Depends(get_db)
):
    """Actualizar una tienda (solo administradores)"""
    repository = StoreRepository(db)
    store = repository.get(store_id)
    if not store:
        raise HTTPException(status_code=404, detail="Tienda no encontrada")
    return repository.update(store_id, store_data)

@router.delete("/stores/{store_id}")
def delete_store(
    store_id: int = Path(..., title="ID de la tienda"),
    db: Session = Depends(get_db)
):
    """Eliminar una tienda (solo administradores)"""
    repository = StoreRepository(db)
    store = repository.get(store_id)
    if not store:
        raise HTTPException(status_code=404, detail="Tienda no encontrada")
    repository.delete(store_id)
    return {"message": "Tienda eliminada correctamente"}

# Rutas para ejecutar scraping manualmente
@router.post("/run-scraper/{store_id}")
async def run_scraper(
    store_id: int = Path(..., title="ID de la tienda"),
    db: Session = Depends(get_db)
):
    """Ejecutar scraper para una tienda específica (solo administradores)"""
    # Verificar que la tienda existe
    repository = StoreRepository(db)
    store = repository.get(store_id)
    if not store:
        raise HTTPException(status_code=404, detail="Tienda no encontrada")
        
    # Importar y ejecutar la tarea de scraping
    from ...core.tasks import run_store_spider
    
    # Ejecutar de forma asíncrona
    task_id = await run_store_spider.delay(store_id=store_id)
    
    return {
        "message": f"Scraper iniciado para {store.name}",
        "task_id": str(task_id),
        "store_id": store_id
    }

@router.get("/scraper-tasks")
async def get_scraper_tasks():
    """Obtener estado de las tareas de scraping (solo administradores)"""
    from ...core.tasks import app as celery_app
    
    # Obtener tareas activas
    i = celery_app.control.inspect()
    active_tasks = i.active() or {}
    scheduled_tasks = i.scheduled() or {}
    
    # Formatear resultados
    all_tasks = []
    
    for worker, tasks in active_tasks.items():
        for task in tasks:
            all_tasks.append({
                "id": task["id"],
                "name": task["name"],
                "worker": worker,
                "args": task["args"],
                "kwargs": task["kwargs"],
                "status": "running",
                "start_time": task["time_start"]
            })
    
    for worker, tasks in scheduled_tasks.items():
        for task in tasks:
            all_tasks.append({
                "id": task["request"]["id"],
                "name": task["request"]["name"],
                "worker": worker,
                "args": task["request"]["args"],
                "kwargs": task["request"]["kwargs"],
                "status": "scheduled",
                "eta": task["eta"]
            })
    
    return all_tasks