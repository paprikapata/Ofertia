# src/api/models/product.py
from pydantic import BaseModel, Field, validator, HttpUrl
from typing import Optional, List, Dict, Any
from datetime import datetime
import re

class ProductBase(BaseModel):
    name: str = Field(..., min_length=3, max_length=255)
    store_id: int = Field(..., gt=0)
    description: Optional[str] = None
    brand: Optional[str] = Field(None, max_length=100)
    model: Optional[str] = Field(None, max_length=100)
    store_sku: Optional[str] = Field(None, max_length=100)
    url: Optional[HttpUrl] = None
    image_url: Optional[HttpUrl] = None
    current_price: Optional[float] = Field(None, gt=0)
    rating: Optional[float] = Field(None, ge=0, le=5)
    review_count: Optional[int] = Field(None, ge=0)
    in_stock: Optional[bool] = True
    
    @validator('name')
    def name_must_be_valid(cls, v):
        if not v.strip():
            raise ValueError('El nombre no puede estar vacío')
        if len(v) < 3:
            raise ValueError('El nombre debe tener al menos 3 caracteres')
        return v
        
    @validator('current_price')
    def price_must_be_positive(cls, v):
        if v is not None and v <= 0:
            raise ValueError('El precio debe ser mayor que cero')
        return v
        
    @validator('store_sku')
    def sku_must_be_valid(cls, v):
        if v and not re.match(r'^[A-Za-z0-9._-]+$', v):
            raise ValueError('El SKU solo puede contener letras, números, puntos, guiones y guiones bajos')
        return v

class ProductCreate(ProductBase):
    category_ids: Optional[List[int]] = None
    primary_category_id: Optional[int] = None
    specs: Optional[Dict[str, Any]] = None

class ProductUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=3, max_length=255)
    description: Optional[str] = None
    brand: Optional[str] = Field(None, max_length=100)
    model: Optional[str] = Field(None, max_length=100)
    url: Optional[HttpUrl] = None
    image_url: Optional[HttpUrl] = None
    current_price: Optional[float] = Field(None, gt=0)
    rating: Optional[float] = Field(None, ge=0, le=5)
    review_count: Optional[int] = Field(None, ge=0)
    in_stock: Optional[bool] = None
    category_ids: Optional[List[int]] = None
    
    @validator('name')
    def name_must_be_valid(cls, v):
        if v is not None:
            if not v.strip():
                raise ValueError('El nombre no puede estar vacío')
            if len(v) < 3:
                raise ValueError('El nombre debe tener al menos 3 caracteres')
        return v
        
    @validator('current_price')
    def price_must_be_positive(cls, v):
        if v is not None and v <= 0:
            raise ValueError('El precio debe ser mayor que cero')
        return v

class ProductResponse(ProductBase):
    id: int
    normalized_name: str
    created_at: datetime
    last_updated: datetime
    
    class Config:
        orm_mode = True