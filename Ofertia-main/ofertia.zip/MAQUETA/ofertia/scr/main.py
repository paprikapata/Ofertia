# src/main.py (monolito)
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware

from .api.routes import products, stores, categories, admin, auth
from .api.middleware.cache_middleware import CacheMiddleware
from .api.middleware.monitoring_middleware import MonitoringMiddleware
from .core.config import settings

app = FastAPI(
    title="Ofertia API",
    description="API para el comparador de precios Ofertia",
    version="1.0.0"
)

# Agregar middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

app.add_middleware(MonitoringMiddleware)

app.add_middleware(
    CacheMiddleware,
    exclude_paths=["/admin", "/api/v1/admin"],
    cache_seconds=settings.CACHE_TTL
)

# Incluir routers
app.include_router(products.router, prefix="/api/v1/products", tags=["products"])
app.include_router(stores.router, prefix="/api/v1/stores", tags=["stores"])
app.include_router(categories.router, prefix="/api/v1/categories", tags=["categories"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["admin"])
app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])

@app.get("/", tags=["health"])
def health_check():
    return {"status": "ok", "version": settings.VERSION}