# src/services/product_service.py
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from ..db.models import Product, Store, Price, Category, ProductCategory
from ..db.repositories.product_repository import ProductRepository
from ..api.models.product import ProductCreate, ProductUpdate

class ProductService:
    def __init__(self, db: Session):
        self.db = db
        self.repository = ProductRepository(db)
        
    def get_product_by_id(self, product_id: int):
        """Obtener un producto por su ID"""
        return self.repository.get(product_id)
    
    def search_products(
        self,
        search: Optional[str] = None,
        category_id: Optional[int] = None,
        min_price: Optional[float] = None,
        max_price: Optional[float] = None,
        store_ids: Optional[List[int]] = None,
        brands: Optional[List[str]] = None,
        in_stock: Optional[bool] = None,
        sort_by: str = "current_price",
        sort_order: str = "asc",
        skip: int = 0,
        limit: int = 20
    ):
        """Buscar productos con múltiples filtros"""
        return self.repository.search(
            search=search,
            category_id=category_id,
            min_price=min_price,
            max_price=max_price,
            store_ids=store_ids,
            brands=brands,
            in_stock=in_stock,
            sort_by=sort_by,
            sort_order=sort_order,
            skip=skip,
            limit=limit
        )
        
    def get_price_history(self, product_id: int, days: int = 30):
        """Obtener historial de precios de un producto"""
        return self.repository.get_price_history(product_id, days)
        
    def compare_products(self, product_ids: List[int]):
        """Comparar múltiples productos"""
        products = [self.repository.get(pid) for pid in product_ids if self.repository.get(pid)]
        
        if not products:
            return []
            
        # Obtener precio actual y más bajo en cada tienda
        result = []
        for product in products:
            stores = self.repository.get_product_stores(product.id)
            result.append({
                "id": product.id,
                "name": product.name,
                "brand": product.brand,
                "model": product.model,
                "image_url": product.image_url,
                "stores": [
                    {
                        "store_id": store.id,
                        "store_name": store.name,
                        "current_price": price,
                        "lowest_price": self.repository.get_lowest_price(product.id, store.id),
                        "in_stock": in_stock
                    }
                    for store, price, in_stock in stores
                ],
                "specifications": self.repository.get_product_specifications(product.id)
            })
            
        return result
        
    def find_similar_products(self, product_id: int, limit: int = 5):
        """Encontrar productos similares"""
        product = self.repository.get(product_id)
        if not product:
            return []
            
        # Buscar por nombre similar y misma categoría
        return self.repository.find_similar(product, limit)
        
    def get_best_price_by_product(self, product_name: str):
        """Obtener el mejor precio para un producto específico en todas las tiendas"""
        return self.repository.get_best_price_by_name(product_name)