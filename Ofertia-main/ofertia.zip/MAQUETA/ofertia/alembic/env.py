# alembic/env.py (configuración básica)
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool
from alembic import context
from src.db.models import Base
from src.core.config import settings

# Esta es la configuración de Alembic
config = context.config

# Configure la conexión de la base de datos desde settings
config.set_main_option("sqlalchemy.url", settings.DATABASE_URL)

# Añadir el modelo al contexto de Alembic
target_metadata = Base.metadata

# ...resto de configuración

def run_migrations_online():
    # ...configuración
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            # Otras configuraciones
        )
        with context.begin_transaction():
            context.run_migrations()