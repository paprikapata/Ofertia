CREATE DATABASE IF NOT EXISTS ofertia;
USE ofertia;

CREATE TABLE IF NOT EXISTS productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  categoria VARCHAR(50),
  titulo VARCHAR(255),
  precio DECIMAL(12,2),
  imagen VARCHAR(255)
);

INSERT INTO productos (categoria, titulo, precio, imagen) VALUES
('Tecnología', 'Samsung Galaxy S23 128GB', 3200000, 'https://images.samsung.com/is/image/samsung/p6pim/co/2302/gallery/co-galaxy-s23-s911-sm-s911bzadeco-thumb-534172010?$344_344_PNG$'),
('Tecnología', 'Apple AirPods Pro 2da Gen', 1100000, 'https://i.linio.com/p/2b8e2b8e2b8e2b8e2b8e2b8e2b8e2b8e-product.jpg'),
('Tecnología', 'Portátil Lenovo 15.6\" Ryzen 5 8GB 512GB SSD', 2200000, 'https://exitocol.vtexassets.com/arquivos/ids/15572825-800-auto?v=638486324964200000&width=800&height=auto&aspect=true'),
('Tecnología', 'Xiaomi Redmi Note 12 128GB', 850000, 'https://falabella.scene7.com/is/image/FalabellaCO/8812311_1?wid=800&hei=800&qlt=70'),
('Tecnología', 'Audífonos Bluetooth JBL Tune 510BT', 120000, 'https://i.pinimg.com/736x/68/9c/9b/689c9b23e5254514197b9b209310e34d.jpg'),
('Tecnología', 'Smartwatch Amazfit Bip U', 220000, 'https://i.linio.com/p/1b2e3b4e5b6e7b8e9b0e1b2e3b4e5b6e-product.jpg'),
('Tecnología', 'Tablet Samsung Galaxy Tab A8 64GB', 750000, 'https://i.linio.com/p/3b4e5b6e7b8e9b0e1b2e3b4e5b6e7b8e-product.jpg'),
('Tecnología', 'Monitor LG 24\'\' Full HD IPS', 520000, 'https://i.linio.com/p/4b5e6b7e8b9e0b1e2b3e4b5e6b7e8b9e-product.jpg'),
('Tecnología', 'Disco Duro Externo Seagate 1TB', 210000, 'https://i.linio.com/p/5b6e7b8e9b0e1b2e3b4e5b6e7b8e9b0e-product.jpg'),
('Tecnología', 'Teclado Mecánico Redragon Kumara', 150000, 'https://i.linio.com/p/6b7e8b9e0b1e2b3e4b5e6b7e8b9e0b1e-product.jpg'),
('Tecnología', 'Mouse Inalámbrico Logitech M185', 45000, 'https://i.linio.com/p/7b8e9b0e1b2e3b4e5b6e7b8e9b0e1b2e-product.jpg'),
('Tecnología', 'Cámara Web Logitech C920 HD', 230000, 'https://i.linio.com/p/8b9e0b1e2b3e4b5e6b7e8b9e0b1e2b3e-product.jpg'),
('Tecnología', 'Impresora HP Ink Tank 315', 520000, 'https://i.linio.com/p/9b0e1b2e3b4e5b6e7b8e9b0e1b2e3b4e-product.jpg'),
('Tecnología', 'Smart TV LG 50\'\' 4K UHD', 1499000, 'https://i.linio.com/p/0b1e2b3e4b5e6b7e8b9e0b1e2b3e4b5e-product.jpg'),
('Tecnología', 'Google Chromecast 4K con Google TV', 250000, 'https://i.linio.com/p/1c2d3e4f5g6h7i8j9k0l1m2n3o4p5q6r-product.jpg');
-- Agrega más productos según lo necesites