# src/db/models.py
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import datetime

Base = declarative_base()

class Store(Base):
    __tablename__ = "stores"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, unique=True)
    normalized_name = Column(String(100), nullable=False, index=True)
    website = Column(String(255))
    logo_url = Column(String(255))
    spider_name = Column(String(50))  # Nombre del spider que extrae datos de esta tienda
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    
    # Relaciones
    products = relationship("Product", back_populates="store")
    prices = relationship("Price", back_populates="store")

class Category(Base):
    __tablename__ = "categories"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    slug = Column(String(120), nullable=False, unique=True, index=True)
    parent_id = Column(Integer, ForeignKey("categories.id"), nullable=True)
    level = Column(Integer, default=0)  # Nivel de profundidad en la jerarquía
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relaciones
    parent = relationship("Category", remote_side=[id], backref="subcategories")
    products = relationship("ProductCategory", back_populates="category")
    
class Product(Base):
    __tablename__ = "products"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    normalized_name = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    brand = Column(String(100), nullable=True, index=True)
    model = Column(String(100), nullable=True)
    store_id = Column(Integer, ForeignKey("stores.id"), nullable=False)
    store_sku = Column(String(100), nullable=True, index=True)  # SKU en la tienda
    url = Column(String(500), nullable=True)
    image_url = Column(String(500), nullable=True)
    current_price = Column(Float, nullable=True)  # Precio actual para facilitar búsquedas
    rating = Column(Float, nullable=True)  # Calificación promedio (1-5)
    review_count = Column(Integer, nullable=True)  # Número de reseñas
    in_stock = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    last_updated = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relaciones
    store = relationship("Store", back_populates="products")
    prices = relationship("Price", back_populates="product")
    specifications = relationship("ProductSpecification", back_populates="product")
    categories = relationship("ProductCategory", back_populates="product")
    
class ProductCategory(Base):
    __tablename__ = "product_categories"
    
    product_id = Column(Integer, ForeignKey("products.id"), primary_key=True)
    category_id = Column(Integer, ForeignKey("categories.id"), primary_key=True)
    is_primary = Column(Boolean, default=False)  # Indica si es la categoría principal
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relaciones
    product = relationship("Product", back_populates="categories")
    category = relationship("Category", back_populates="products")
    
class Price(Base):
    __tablename__ = "prices"
    
    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    store_id = Column(Integer, ForeignKey("stores.id"), nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String(3), default="COP")  # ISO 4217 currency code
    discount_percentage = Column(Float, nullable=True)  # Porcentaje de descuento si existe
    original_amount = Column(Float, nullable=True)  # Precio antes del descuento
    timestamp = Column(DateTime, default=datetime.datetime.utcnow, index=True)
    is_available = Column(Boolean, default=True)  # Indica si el producto estaba disponible
    
    # Relaciones
    product = relationship("Product", back_populates="prices")
    store = relationship("Store", back_populates="prices")
    
class ProductSpecification(Base):
    __tablename__ = "product_specifications"
    
    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    key = Column(String(100), nullable=False)  # Nombre de la especificación
    value = Column(String(255), nullable=True)  # Valor de la especificación
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relaciones
    product = relationship("Product", back_populates="specifications")
    
class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relaciones
    price_alerts = relationship("PriceAlert", back_populates="user")
    
class PriceAlert(Base):
    __tablename__ = "price_alerts"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    target_price = Column(Float, nullable=False)  # Precio objetivo para la alerta
    is_active = Column(Boolean, default=True)
    is_triggered = Column(Boolean, default=False)  # Si la alerta ya fue activada
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    triggered_at = Column(DateTime, nullable=True)  # Cuándo se activó la alerta
    
    # Relaciones
    user = relationship("User", back_populates="price_alerts")
    product = relationship("Product")

    # src/db/models.py (ampliación con índices)

# Índices para Product
Index('idx_product_normalized_name_store', Product.normalized_name, Product.store_id)
Index('idx_product_current_price', Product.current_price)
Index('idx_product_brand', Product.brand)
Index('idx_product_in_stock', Product.in_stock)

# Índices para Price
Index('idx_price_product_store', Price.product_id, Price.store_id)
Index('idx_price_timestamp', Price.timestamp)
Index('idx_price_amount', Price.amount)

# Índices para ProductSpecification
Index('idx_spec_product_key', ProductSpecification.product_id, ProductSpecification.key)

# Añadir a src/db/models.py
from sqlalchemy import Boolean, DateTime

# Agregar a la tabla Product
class Product(Base):
    # ...campos existentes
    
    is_deleted = Column(Boolean, default=False, index=True)
    deleted_at = Column(DateTime, nullable=True)

# Modificar el método delete del repositorio
def delete(self, product_id: int):
    """Soft delete de un producto"""
    db_product = self.get(product_id)
    if not db_product:
        return False
        
    # Marcar como eliminado en lugar de eliminar físicamente
    db_product.is_deleted = True
    db_product.deleted_at = datetime.datetime.utcnow()
    self.db.commit()
    return True

# Modificar queries para excluir eliminados
def list(self, ...):
    query = self.db.query(Product).filter(Product.is_deleted == False)
    # ...resto del método