# src/api/routes/products.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from ..models.product import ProductCreate, ProductUpdate, ProductResponse
from ...db.session import get_db
from ...db.repositories.product_repository import ProductRepository

router = APIRouter()

@router.post("/", response_model=ProductResponse)
def create_product(
    product: ProductCreate,
    db: Session = Depends(get_db)
):
    """Crear un nuevo producto (generalmente usado por administradores)"""
    repository = ProductRepository(db)
    return repository.create(product)

@router.get("/{product_id}", response_model=ProductResponse)
def get_product(
    product_id: int,
    db: Session = Depends(get_db)
):
    """Obtener un producto por ID"""
    repository = ProductRepository(db)
    product = repository.get(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    return product

@router.put("/{product_id}", response_model=ProductResponse)
def update_product(
    product_id: int,
    product: ProductUpdate,
    db: Session = Depends(get_db)
):
    """Actualizar un producto existente"""
    repository = ProductRepository(db)
    product_db = repository.get(product_id)
    if not product_db:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    return repository.update(product_id, product)

@router.delete("/{product_id}")
def delete_product(
    product_id: int,
    db: Session = Depends(get_db)
):
    """Eliminar un producto (soft delete)"""
    repository = ProductRepository(db)
    product_db = repository.get(product_id)
    if not product_db:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    repository.delete(product_id)
    return {"message": "Producto eliminado correctamente"}

@router.get("/", response_model=List[ProductResponse])
def list_products(
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    store_id: Optional[int] = None,
    category_id: Optional[int] = None,
    in_stock: Optional[bool] = None,
    sort_by: str = "current_price",
    sort_order: str = "asc",
    db: Session = Depends(get_db)
):
    """Listar productos con filtros y ordenamiento"""
    repository = ProductRepository(db)
    return repository.list(
        skip=skip,
        limit=limit,
        search=search,
        min_price=min_price,
        max_price=max_price,
        store_id=store_id,
        category_id=category_id,
        in_stock=in_stock,
        sort_by=sort_by,
        sort_order=sort_order
    )