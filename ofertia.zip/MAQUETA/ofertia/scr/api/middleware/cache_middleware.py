# src/api/middleware/cache_middleware.py
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from ...core.cache import get_cache_key, get_from_cache, set_in_cache
import hashlib

class CacheMiddleware(BaseHTTPMiddleware):
    def __init__(
        self, 
        app,
        exclude_paths=None,
        cache_seconds=3600
    ):
        super().__init__(app)
        self.exclude_paths = exclude_paths or []
        self.cache_seconds = cache_seconds
        
    async def dispatch(self, request: Request, call_next):
        # No usar caché para métodos distintos a GET
        if request.method != "GET":
            return await call_next(request)
            
        # Comprobar si la ruta debe excluirse
        path = request.url.path
        if any(path.startswith(excluded) for excluded in self.exclude_paths):
            return await call_next(request)
            
        # Generar clave de caché
        cache_key = self._generate_cache_key(request)
        
        # Intentar obtener de caché
        cached_response = get_from_cache(cache_key)
        if cached_response:
            return JSONResponse(
                content=cached_response,
                headers={"X-Cache": "HIT"}
            )
            
        # Si no está en caché, ejecutar el endpoint
        response = await call_next(request)
        
        # Si es JSONResponse, guardar en caché
        if isinstance(response, JSONResponse):
            response_body = response.body.decode("utf-8")
            set_in_cache(
                cache_key,
                response.body,
                expire_seconds=self.cache_seconds
            )
            
            # Añadir header de caché
            response.headers["X-Cache"] = "MISS"
            
        return response
        
    def _generate_cache_key(self, request: Request) -> str:
        """Genera una clave única para la caché basada en la URL y query params"""
        url = str(request.url)
        
        # Usar MD5 para crear una clave más compacta
        url_hash = hashlib.md5(url.encode()).hexdigest()
        
        return f"api:response:{url_hash}"