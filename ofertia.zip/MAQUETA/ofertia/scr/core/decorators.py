# src/core/decorators.py
from functools import wraps
from typing import Any, Callable, Optional
from .cache import get_cache_key, get_from_cache, set_in_cache

def cached(
    prefix: str,
    expire_seconds: int = 3600,
    cache_none: bool = False
):
    """
    Decorador para cachear resultados de funciones
    
    Args:
        prefix: Prefijo para la clave de caché
        expire_seconds: Tiempo de expiración en segundos
        cache_none: Si se deben cachear resultados None
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Generar clave de caché
            cache_key = get_cache_key(prefix, func.__name__, *args, **kwargs)
            
            # Intentar obtener de caché
            cached_result = get_from_cache(cache_key)
            if cached_result is not None:
                return cached_result
                
            # Ejecutar función
            result = func(*args, **kwargs)
            
            # Guardar en caché si no es None o si cache_none es True
            if result is not None or cache_none:
                set_in_cache(cache_key, result, expire_seconds)
                
            return result
        return wrapper
    return decorator