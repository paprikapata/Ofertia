# src/core/metrics.py
import time
from statsd import StatsClient
from prometheus_client import Counter, Histogram, Gauge
from functools import wraps
from typing import Callable, Optional, Dict, Any
from .config import settings

# Configuración de StatsD
statsd = StatsClient(
    host=settings.STATSD_HOST,
    port=settings.STATSD_PORT,
    prefix='ofertia'
)

# Métricas de Prometheus
SCRAPING_COUNTER = Counter(
    'scraped_items_total',
    'Total number of items scraped',
    ['store', 'status']
)

API_REQUESTS = Counter(
    'api_requests_total',
    'Total number of API requests',
    ['method', 'endpoint', 'status']
)

DB_QUERIES = Counter(
    'db_queries_total',
    'Total number of database queries'
)

REQUEST_DURATION = Histogram(
    'request_duration_seconds',
    'Request duration in seconds',
    ['method', 'endpoint'],
    buckets=(0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10)
)

ACTIVE_USERS = Gauge(
    'active_users',
    'Number of active users'
)

CACHE_HITS = Counter(
    'cache_hits_total',
    'Total number of cache hits',
    ['cache_type']
)

CACHE_MISSES = Counter(
    'cache_misses_total',
    'Total number of cache misses',
    ['cache_type']
)

PRODUCTS_COUNT = Gauge(
    'products_count',
    'Total number of products',
    ['store']
)

SCRAPER_DURATION = Histogram(
    'scraper_duration_seconds',
    'Scraper execution duration in seconds',
    ['store'],
    buckets=(1, 5, 10, 30, 60, 120, 300, 600, 1800, 3600)
)

# Decoradores para instrumentar código

def track_execution_time(metric_name: str):
    """Decorador para medir tiempo de ejecución de una función"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            
            # Registrar en StatsD
            statsd.timing(metric_name, execution_time * 1000)  # StatsD usa milisegundos
            
            return result
        return wrapper
    return decorator

def track_api_request(endpoint: str):
    """Decorador para rastrear solicitudes a la API"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            method = "GET"  # Por defecto
            
            # Intentar obtener el método HTTP real
            if args and hasattr(args[0], 'method'):
                method = args[0].method
                
            try:
                start_time = time.time()
                result = func(*args, **kwargs)
                status = getattr(result, 'status_code', 200)
                
                # Registrar métricas
                API_REQUESTS.labels(method=method, endpoint=endpoint, status=status).inc()
                REQUEST_DURATION.labels(method=method, endpoint=endpoint).observe(time.time() - start_time)
                
                return result
            except Exception as e:
                API_REQUESTS.labels(method=method, endpoint=endpoint, status=500).inc()
                raise e
                
        return wrapper
    return decorator

# Funciones de utilidad para registrar métricas

def record_scraped_item(store: str, status: str = 'success'):
    """Registra un elemento raspado"""
    SCRAPING_COUNTER.labels(store=store, status=status).inc()
    statsd.incr(f'scraping.{store}.{status}')

def record_db_query():
    """Registra una consulta a la base de datos"""
    DB_QUERIES.inc()
    statsd.incr('db.queries')

def record_scraper_execution(store: str, duration_seconds: float):
    """Registra la duración de ejecución de un scraper"""
    SCRAPER_DURATION.labels(store=store).observe(duration_seconds)
    statsd.timing(f'scraper.{store}.duration', duration_seconds * 1000)

def record_cache_result(cache_type: str, hit: bool):
    """Registra un resultado de caché (hit o miss)"""
    if hit:
        CACHE_HITS.labels(cache_type=cache_type).inc()
        statsd.incr(f'cache.{cache_type}.hit')
    else:
        CACHE_MISSES.labels(cache_type=cache_type).inc()
        statsd.incr(f'cache.{cache_type}.miss')

def update_products_count(store: str, count: int):
    """Actualiza el contador de productos por tienda"""
    PRODUCTS_COUNT.labels(store=store).set(count)
    statsd.gauge(f'products.{store}.count', count)

def track_active_users(count: int):
    """Actualiza el contador de usuarios activos"""
    ACTIVE_USERS.set(count)
    statsd.gauge('users.active', count)