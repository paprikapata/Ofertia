# src/scrapers/pipelines/processing_pipeline.py
from scrapy import Spider
from scrapy.exceptions import DropItem
from sqlalchemy.orm import Session
from ...db.session import get_db
from ...services.batch_update_service import BatchUpdateService
import logging
import datetime

class ItemProcessingPipeline:
    def __init__(self):
        """Inicializar el pipeline"""
        self.items_buffer = []
        self.buffer_size = 100  # Número de ítems antes de procesar en lote
        
    def open_spider(self, spider):
        """Configuración al iniciar el spider"""
        self.store_name = getattr(spider, 'store_name', None)
        self.db = next(get_db())
        self.batch_service = BatchUpdateService(self.db)
        self.items_count = 0
        self.start_time = datetime.datetime.now()
        logging.info(f"Iniciando spider para {self.store_name}")
        
    def close_spider(self, spider):
        """Acciones al finalizar el spider"""
        # Procesar los elementos restantes en el buffer
        if self.items_buffer:
            self._process_batch()
            
        duration = datetime.datetime.now() - self.start_time
        logging.info(f"Spider completado para {self.store_name}. "
                    f"Procesados {self.items_count} ítems en {duration}")
        self.db.close()
        
    def process_item(self, item, spider):
        """Procesar cada ítem extraído por el spider"""
        # Validar ítem antes de procesarlo
        if not self._validate_item(item):
            raise DropItem(f"Ítem inválido: {item}")
            
        # Aplicar transformaciones
        item = self._transform_item(item, spider)
        
        # Añadir al buffer
        self.items_buffer.append(item)
        
        # Procesar en lote si se alcanza el tamaño
        if len(self.items_buffer) >= self.buffer_size:
            self._process_batch()
            
        return item
        
    def _validate_item(self, item):
        """Validar que el ítem tenga los campos requeridos"""
        required_fields = ['name', 'price', 'store_id', 'url']
        
        for field in required_fields:
            if field not in item or item[field] is None:
                logging.warning(f"Ítem descartado - falta campo {field}: {item}")
                return False
                
        # Validar formato de precio
        if 'price' in item and not isinstance(item['price'], (int, float)):
            try:
                item['price'] = float(item['price'])
            except (ValueError, TypeError):
                logging.warning(f"Ítem descartado - precio inválido: {item}")
                return False
                
        return True
        
    def _transform_item(self, item, spider):
        """Aplicar transformaciones al ítem"""
        # Si no tiene store_id, asignar desde el spider
        if 'store_id' not in item and hasattr(spider, 'store_id'):
            item['store_id'] = spider.store_id
            
        # Normalizar el nombre
        if 'name' in item:
            item['name'] = item['name'].strip()
            
        # Convertir a float el precio
        if 'price' in item and not isinstance(item['price'], float):
            item['price'] = float(item['price'])
            
        # Asegurar URLs absolutas
        if 'url' in item and not item['url'].startswith(('http://', 'https://')):
            base_url = getattr(spider, 'base_url', None)
            if base_url:
                item['url'] = f"{base_url.rstrip('/')}/{item['url'].lstrip('/')}"
                
        if 'image_url' in item and item['image_url'] and not item['image_url'].startswith(('http://', 'https://')):
            base_url = getattr(spider, 'base_url', None)
            if base_url:
                item['image_url'] = f"{base_url.rstrip('/')}/{item['image_url'].lstrip('/')}"
                
        return item
        
    def _process_batch(self):
        """Procesar un lote de ítems raspados"""
        if not self.items_buffer:
            return
            
        try:
            # Actualizar productos en lote
            count = self.batch_service.upsert_products(self.items_buffer)
            self.items_count += count
            logging.info(f"Procesados {count} ítems de {self.store_name} "
                        f"({self.items_count} total)")
        except Exception as e:
            logging.error(f"Error al procesar lote: {str(e)}")
        finally:
            # Limpiar buffer
            self.items_buffer = []