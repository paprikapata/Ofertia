# src/scrapers/pipelines/product_pipeline.py
import dateutil.parser
from sqlalchemy.orm import Session
from ..db.models import Product, Store, Price, ProductSpecification
from ..db.session import get_db
from ..utils.text_normalizer import normalize_product_name

class ProductPipeline:
    def __init__(self):
        """Inicializa el pipeline"""
        self.db = next(get_db())
        
    def process_item(self, item, spider):
        """Procesa un elemento raspado y lo almacena en la base de datos"""
        
        # 1. Normalizar y limpiar datos
        item = self._clean_item(item)
        
        # 2. Buscar o crear la tienda
        store = self._get_or_create_store(item['store'], spider.name)
        
        # 3. Buscar producto existente o crear uno nuevo
        product = self._get_or_create_product(item, store)
        
        # 4. Registrar precio actual
        self._register_price(product, item['price'], store)
        
        # 5. Actualizar especificaciones
        if 'specs' in item and item['specs']:
            self._update_specifications(product, item['specs'])
        
        # 6. Actualizar otros datos (stock, imágenes, etc.)
        self._update_product_data(product, item)
        
        # Confirmar cambios en la base de datos
        self.db.commit()
        
        return item
    
    def _clean_item(self, item):
        """Limpia y normaliza los datos del ítem"""
        if 'name' in item:
            item['name'] = item['name'].strip()
            item['normalized_name'] = normalize_product_name(item['name'])
            
        if 'price' in item and item['price']:
            # Asegurarse de que el precio sea un float
            try:
                item['price'] = float(item['price'])
            except (ValueError, TypeError):
                item['price'] = None
        
        # Más limpieza y normalización...
        
        return item
        
    def _get_or_create_store(self, store_name, spider_name):
        """Obtiene o crea la tienda"""
        store = self.db.query(Store).filter(Store.name == store_name).first()
        if not store:
            store = Store(
                name=store_name,
                spider_name=spider_name,
                website=f"https://www.{store_name.lower()}.com.co",  # Aproximación básica
                active=True
            )
            self.db.add(store)
            self.db.flush()  # Para obtener el ID asignado
        
        return store
        
    def _get_or_create_product(self, item, store):
        """Busca un producto existente o crea uno nuevo"""
        # Buscar por SKU en la tienda específica si está disponible
        product = None
        if 'sku' in item and item['sku']:
            product = self.db.query(Product).filter(
                Product.store_id == store.id,
                Product.store_sku == item['sku']
            ).first()
        
        # Si no se encuentra por SKU, buscar por nombre normalizado
        if not product and 'normalized_name' in item:
            product = self.db.query(Product).filter(
                Product.store_id == store.id,
                Product.normalized_name == item['normalized_name']
            ).first()
        
        # Si no existe, crear nuevo producto
        if not product:
            product = Product(
                name=item['name'],
                normalized_name=item.get('normalized_name', ''),
                store_id=store.id,
                store_sku=item.get('sku', ''),
                url=item.get('url', ''),
                image_url=item.get('image_url', ''),
                description=item.get('description', ''),
                category=item.get('category', ''),
                brand=item.get('brand', '')
            )
            self.db.add(product)
            self.db.flush()  # Para obtener el ID asignado
        else:
            # Actualizar datos del producto
            product.url = item.get('url', product.url)
            product.image_url = item.get('image_url', product.image_url)
            product.description = item.get('description', product.description)
            product.category = item.get('category', product.category)
            product.brand = item.get('brand', product.brand)
            
        return product
        
    def _register_price(self, product, price, store):
        """Registra el precio actual del producto"""
        if price is None:
            return
            
        # Crear nuevo registro de precio
        new_price = Price(
            product_id=product.id,
            store_id=store.id,
            amount=price,
            currency='COP',  # Moneda por defecto para Colombia
            timestamp=datetime.datetime.now()
        )
        self.db.add(new_price)
        
        # Actualizar precio actual en el producto
        product.current_price = price
        product.last_updated = datetime.datetime.now()
        
    def _update_specifications(self, product, specs):
        """Actualiza las especificaciones del producto"""
        for key, value in specs.items():
            # Buscar especificación existente
            spec = self.db.query(ProductSpecification).filter(
                ProductSpecification.product_id == product.id,
                ProductSpecification.key == key
            ).first()
            
            if spec:
                # Actualizar valor si existe
                spec.value = value
            else:
                # Crear nueva especificación
                spec = ProductSpecification(
                    product_id=product.id,
                    key=key,
                    value=value
                )
                self.db.add(spec)
                
    def _update_product_data(self, product, item):
        """Actualiza datos adicionales del producto"""
        if 'stock' in item:
            product.in_stock = item['stock']
            
        if 'rating' in item:
            product.rating = item['rating']
            
        if 'review_count' in item:
            product.review_count = item['review_count']
        
        # Más actualizaciones según los datos disponibles