# src/scrapers/middleware/playwright_middleware.py
from scrapy import signals
from scrapy.http import HtmlResponse
from playwright.async_api import async_playwright

class PlaywrightMiddleware:
    @classmethod
    async def from_crawler(cls, crawler):
        middleware = cls()
        crawler.signals.connect(middleware.spider_opened, signal=signals.spider_opened)
        crawler.signals.connect(middleware.spider_closed, signal=signals.spider_closed)
        return middleware

    async def spider_opened(self, spider):
        self.playwright = await async_playwright().start()
        self.browser = await self.playwright.chromium.launch(headless=True)

    async def spider_closed(self, spider):
        await self.browser.close()
        await self.playwright.stop()

    async def process_request(self, request, spider):
        # Usar Playwright solo para ciertos sitios o URLs
        if 'use_playwright' in request.meta:
            page = await self.browser.new_page()
            
            # Configurar interceptores, headers, etc
            if 'user_agent' in request.meta:
                await page.set_extra_http_headers({'User-Agent': request.meta['user_agent']})
            
            # Navegar a la URL
            await page.goto(request.url, wait_until='networkidle')
            
            # Esperar elementos específicos si es necesario
            if 'wait_for' in request.meta:
                await page.wait_for_selector(request.meta['wait_for'])
            
            # Realizar interacciones si es necesario
            if 'click' in request.meta:
                await page.click(request.meta['click'])
                await page.wait_for_load_state('networkidle')
            
            # Extraer contenido
            content = await page.content()
            await page.close()
            
            # Devolver respuesta procesada
            return HtmlResponse(
                url=request.url,
                body=content,
                encoding='utf-8',
                request=request
            )
        
        # Para solicitudes normales, continuar con el procesamiento estándar
        return None