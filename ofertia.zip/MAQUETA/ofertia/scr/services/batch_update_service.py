# src/services/batch_update_service.py
from sqlalchemy.orm import Session
from sqlalchemy.dialects.postgresql import insert
from typing import List, Dict, Any
from ..db.models import Product, Price, ProductSpecification
from ..db.session import get_db
import datetime

class BatchUpdateService:
    def __init__(self, db: Session):
        self.db = db
        
    def upsert_products(self, products_data: List[Dict[str, Any]]):
        """
        Realiza una actualización masiva de productos usando UPSERT
        """
        # Preparar datos para el upsert
        timestamp = datetime.datetime.utcnow()
        products_to_insert = []
        prices_to_insert = []
        specs_to_insert = []
        
        for product_data in products_data:
            # Normalizar datos
            normalized_name = self._normalize_name(product_data.get("name", ""))
            store_id = product_data.get("store_id")
            store_sku = product_data.get("store_sku", "")
            
            # Datos del producto
            product = {
                "name": product_data.get("name", ""),
                "normalized_name": normalized_name,
                "description": product_data.get("description", ""),
                "brand": product_data.get("brand", ""),
                "model": product_data.get("model", ""),
                "store_id": store_id,
                "store_sku": store_sku,
                "url": product_data.get("url", ""),
                "image_url": product_data.get("image_url", ""),
                "current_price": product_data.get("price"),
                "rating": product_data.get("rating"),
                "review_count": product_data.get("review_count"),
                "in_stock": product_data.get("in_stock", True),
                "last_updated": timestamp
            }
            
            products_to_insert.append(product)
            
            # Registro del precio
            if "price" in product_data and product_data["price"] is not None:
                price = {
                    "store_id": store_id,
                    "amount": product_data["price"],
                    "currency": product_data.get("currency", "COP"),
                    "discount_percentage": product_data.get("discount_percentage"),
                    "original_amount": product_data.get("original_price"),
                    "timestamp": timestamp,
                    "is_available": product_data.get("in_stock", True)
                }
                
                # Marcar para inserción posterior cuando tengamos el product_id
                prices_to_insert.append((product, price))
                
            # Especificaciones
            if "specs" in product_data and product_data["specs"]:
                for key, value in product_data["specs"].items():
                    spec = {
                        "key": key,
                        "value": str(value),
                        "created_at": timestamp
                    }
                    
                    # Marcar para inserción posterior cuando tengamos el product_id
                    specs_to_insert.append((product, spec))
        
        # Realizar upsert de productos
        self._upsert_products_batch(products_to_insert)
        
        # Obtener IDs de productos insertados/actualizados
        product_ids = self._get_product_ids(products_to_insert)
        
        # Insertar precios
        self._insert_prices(prices_to_insert, product_ids)
        
        # Insertar especificaciones
        self._insert_specifications(specs_to_insert, product_ids)
        
        return len(products_to_insert)
    
    def _upsert_products_batch(self, products):
        """Upsert masivo de productos usando PostgreSQL"""
        if not products:
            return
            
        # Construir statement de upsert
        stmt = insert(Product).values(products)
        
        # En caso de conflicto, actualizar campos específicos
        update_dict = {
            "name": stmt.excluded.name,
            "description": stmt.excluded.description,
            "url": stmt.excluded.url,
            "image_url": stmt.excluded.image_url,
            "current_price": stmt.excluded.current_price,
            "rating": stmt.excluded.rating,
            "review_count": stmt.excluded.review_count,
            "in_stock": stmt.excluded.in_stock,
            "last_updated": stmt.excluded.last_updated
        }
        
        # Ejecutar upsert
        update_stmt = stmt.on_conflict_do_update(
            constraint="products_store_id_store_sku_key",  # Restricción única
            set_=update_dict
        )
        
        self.db.execute(update_stmt)
        self.db.commit()
    
    def _get_product_ids(self, products):
        """Obtiene los IDs de los productos recién insertados/actualizados"""
        result = {}
        
        for product in products:
            # Buscar por store_id y store_sku
            db_product = self.db.query(Product).filter(
                Product.store_id == product["store_id"],
                Product.store_sku == product["store_sku"]
            ).first()
            
            if db_product:
                # Clave compuesta para identificar el producto
                key = (product["store_id"], product["store_sku"])
                result[key] = db_product.id
        
        return result
    
    def _insert_prices(self, prices_data, product_ids):
        """Inserta registros de precios en lote"""
        if not prices_data:
            return
            
        prices_to_insert = []
        
        for product_info, price_info in prices_data:
            # Buscar ID del producto
            key = (product_info["store_id"], product_info["store_sku"])
            product_id = product_ids.get(key)
            
            if product_id:
                price_info["product_id"] = product_id
                prices_to_insert.append(price_info)
        
        if prices_to_insert:
            self.db.execute(insert(Price).values(prices_to_insert))
            self.db.commit()
    
    def _insert_specifications(self, specs_data, product_ids):
        """Inserta especificaciones de productos en lote"""
        if not specs_data:
            return
            
        specs_to_insert = []
        
        for product_info, spec_info in specs_data:
            # Buscar ID del producto
            key = (product_info["store_id"], product_info["store_sku"])
            product_id = product_ids.get(key)
            
            if product_id:
                spec_info["product_id"] = product_id
                specs_to_insert.append(spec_info)
        
        if specs_to_insert:
            self.db.execute(insert(ProductSpecification).values(specs_to_insert))
            self.db.commit()
    
    def _normalize_name(self, name: str) -> str:
        """Normaliza el nombre del producto para búsquedas y comparaciones"""
        import re
        if not name:
            return ""
            
        name = name.lower()
        name = re.sub(r'[^\w\s]', '', name)  # Eliminar caracteres especiales
        name = re.sub(r'\s+', ' ', name)     # Normalizar espacios
        return name.strip()