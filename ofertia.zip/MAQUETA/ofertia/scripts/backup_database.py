# scripts/backup_database.py
import subprocess
import datetime
import os
import boto3
from src.core.config import settings

def backup_database():
    """Crea un backup de la base de datos y lo sube a S3"""
    
    # Configuración
    DB_NAME = settings.DATABASE_NAME
    DB_USER = settings.DATABASE_USER
    DB_HOST = settings.DATABASE_HOST
    
    # Nombre del archivo de backup
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = f"backup_{DB_NAME}_{timestamp}.sql"
    
    # Crear directorio de backups si no existe
    backup_dir = "backups"
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    backup_path = os.path.join(backup_dir, backup_file)
    
    # Ejecutar pg_dump
    pg_dump_command = [
        "pg_dump",
        f"--host={DB_HOST}",
        f"--username={DB_USER}",
        f"--dbname={DB_NAME}",
        "--format=custom",
        f"--file={backup_path}"
    ]
    
    try:
        # Ejecutar comando
        subprocess.run(
            pg_dump_command,
            env={"PGPASSWORD": settings.DATABASE_PASSWORD},
            check=True,
            capture_output=True
        )
        
        # Comprimir archivo
        compressed_path = f"{backup_path}.gz"
        subprocess.run(["gzip", backup_path], check=True)
        
        # Subir a S3
        if settings.USE_S3_BACKUP:
            s3_client = boto3.client(
                's3',
                aws_access_key_id=settings.AWS_ACCESS_KEY,
                aws_secret_access_key=settings.AWS_SECRET_KEY
            )
            
            s3_path = f"db_backups/{os.path.basename(compressed_path)}"
            s3_client.upload_file(
                compressed_path,
                settings.S3_BACKUP_BUCKET,
                s3_path
            )
            
            print(f"Backup uploaded to S3: {s3_path}")
        
        print(f"Backup completed: {compressed_path}")
        return compressed_path
        
    except subprocess.CalledProcessError as e:
        print(f"Error en backup: {e}")
        return None

if __name__ == "__main__":
    backup_database()