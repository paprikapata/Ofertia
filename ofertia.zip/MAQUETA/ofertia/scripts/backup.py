# scripts/backup.py
import os
import datetime
import subprocess
import boto3
import logging
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configuración
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "ofertia")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")

BACKUP_DIR = os.getenv("BACKUP_DIR", "backups")
S3_BUCKET = os.getenv("S3_BACKUP_BUCKET")
S3_REGION = os.getenv("S3_REGION", "us-east-1")
AWS_ACCESS_KEY = os.getenv("AWS_ACCESS_KEY")
AWS_SECRET_KEY = os.getenv("AWS_SECRET_KEY")

BACKUP_RETENTION_DAYS = int(os.getenv("BACKUP_RETENTION_DAYS", "7"))

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("backup.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("backup")

def create_backup():
    """Crear respaldo de la base de datos"""
    try:
        # Crear directorio si no existe
        if not os.path.exists(BACKUP_DIR):
            os.makedirs(BACKUP_DIR)
        
        # Generar nombre de archivo con timestamp
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"{DB_NAME}_{timestamp}.sql"
        backup_path = os.path.join(BACKUP_DIR, backup_filename)
        
        # Ejecutar pg_dump
        env = os.environ.copy()
        env["PGPASSWORD"] = DB_PASSWORD
        
        command = [
            "pg_dump",
            "-h", DB_HOST,
            "-p", DB_PORT,
            "-U", DB_USER,
            "-F", "c",  # Formato personalizado
            "-b",       # Datos binarios
            "-v",       # Verbose
            "-f", backup_path,
            DB_NAME
        ]
        
        logger.info(f"Iniciando backup: {backup_filename}")
        result = subprocess.run(command, env=env, check=True, capture_output=True, text=True)
        
        logger.info(f"Backup creado: {backup_path}")
        logger.debug(result.stdout)
        
        # Comprimir el archivo
        compressed_path = f"{backup_path}.gz"
        compress_command = ["gzip", "-f", backup_path]
        subprocess.run(compress_command, check=True)
        
        logger.info(f"Backup comprimido: {compressed_path}")
        
        return compressed_path
    except subprocess.CalledProcessError as e:
        logger.error(f"Error en pg_dump: {str(e)}")
        logger.error(f"Salida: {e.stderr}")
        return None
    except Exception as e:
        logger.error(f"Error creando backup: {str(e)}")
        return None

def upload_to_s3(file_path):
    """Subir archivo a S3"""
    if not all([S3_BUCKET, AWS_ACCESS_KEY, AWS_SECRET_KEY]):
        logger.warning("No se ha configurado S3. Omitiendo subida.")
        return False
    
    try:
        s3_client = boto3.client(
            's3',
            aws_access_key_id=AWS_ACCESS_KEY,
            aws_secret_access_key=AWS_SECRET_KEY,
            region_name=S3_REGION
        )
        
        file_name = os.path.basename(file_path)
        s3_key = f"db_backups/{file_name}"
        
        logger.info(f"Subiendo {file_name} a S3 bucket {S3_BUCKET}")
        s3_client.upload_file(file_path, S3_BUCKET, s3_key)
        
        logger.info(f"Archivo subido exitosamente a s3://{S3_BUCKET}/{s3_key}")
        return True
    except Exception as e:
        logger.error(f"Error al subir a S3: {str(e)}")
        return False

def clean_old_backups():
    """Eliminar backups antiguos"""
    try:
        now = datetime.datetime.now()
        retention_date = now - datetime.timedelta(days=BACKUP_RETENTION_DAYS)
        
        logger.info(f"Limpiando backups anteriores a {retention_date.strftime('%Y-%m-%d')}")
        
        # Limpiar backups locales
        for file in os.listdir(BACKUP_DIR):
            file_path = os.path.join(BACKUP_DIR, file)
            if not os.path.isfile(file_path):
                continue
                
            # Extraer fecha del nombre de archivo
            try:
                # Formato esperado: nombre_YYYYMMDD_HHMMSS.sql.gz
                date_part = file.split('_')[1]
                time_part = file.split('_')[2].split('.')[0]
                file_date_str = f"{date_part}_{time_part}"
                file_date = datetime.datetime.strptime(file_date_str, "%Y%m%d_%H%M%S")
                
                if file_date < retention_date:
                    logger.info(f"Eliminando backup antiguo: {file}")
                    os.remove(file_path)
            except (IndexError, ValueError):
                logger.warning(f"No se puede determinar la fecha del archivo: {file}")
        
        # Limpiar backups en S3
        if all([S3_BUCKET, AWS_ACCESS_KEY, AWS_SECRET_KEY]):
            s3_client = boto3.client(
                's3',
                aws_access_key_id=AWS_ACCESS_KEY,
                aws_secret_access_key=AWS_SECRET_KEY,
                region_name=S3_REGION
            )
            
            response = s3_client.list_objects_v2(Bucket=S3_BUCKET, Prefix="db_backups/")
            
            if 'Contents' in response:
                for obj in response['Contents']:
                    key = obj['Key']
                    file_name = os.path.basename(key)
                    
                    try:
                        # Extraer fecha del nombre de archivo
                        date_part = file_name.split('_')[1]
                        time_part = file_name.split('_')[2].split('.')[0]
                        file_date_str = f"{date_part}_{time_part}"
                        file_date = datetime.datetime.strptime(file_date_str, "%Y%m%d_%H%M%S")
                        
                        if file_date < retention_date:
                            logger.info(f"Eliminando backup antiguo de S3: {key}")
                            s3_client.delete_object(Bucket=S3_BUCKET, Key=key)
                                                except (IndexError, ValueError):
                        logger.warning(f"No se puede determinar la fecha del archivo S3: {file_name}")
        
        logger.info("Limpieza de backups antiguos completada")
    except Exception as e:
        logger.error(f"Error al limpiar backups antiguos: {str(e)}")

def main():
    """Función principal para ejecutar el backup"""
    logger.info("Iniciando proceso de backup")
    
    # Crear backup
    backup_file = create_backup()
    if not backup_file:
        logger.error("Proceso de backup fallido")
        return False
    
    # Subir a S3
    upload_success = upload_to_s3(backup_file)
    
    # Limpiar backups antiguos
    clean_old_backups()
    
    logger.info("Proceso de backup completado")
    return True

if __name__ == "__main__":
    main()
                    