<?php 
        include '../MODELO/base_de_datos.php';

    $ID_PRODUCTO=$_POST["ID_PRODUCTO"];
        $PRECIO=$_POST["PRECIO"];
            $NOMBRE_DEL_PRODUCTO=$_POST["NOMBRE_DEL_PRODUCTO"];
                 $FECHA_AGREGADO=$_POST["FECHA_AGREGADO"];
                     $Foto_producto= addslashes(file_get_contents($_FILES['Foto_producto']['tmp_name']));
                 
                $insert="INSERT INTO producto(ID_PRODUCTO, PRECIO, NOMBRE_DEL_PRODUCTO, FECHA_AGREGADO,Foto_producto)VALUES ('$ID_PRODUCTO','$PRECIO','$NOMBRE_DEL_PRODUCTO','$FECHA_AGREGADO','$Foto_producto')";

if($mysqli ->query($insert)) {?>
<script>
    alert("agregado con exito")
    window.location="../vista/html/principal_MS.html"
</script>
<?php
} else{?>
<script>
    alert("no se guardo el producto")
    window.location="../VISTA/HTML/Registrar_producto.html"
</script>
<?php
}
?>
<?php 
        include '../MODELO/base_de_datos.php';

    $ID_PRODUCTO=$_POST["ID_PRODUCTO"];
        $PRECIO=$_POST["PRECIO"];
            $NOMBRE_DEL_PRODUCTO=$_POST["NOMBRE_DEL_PRODUCTO"];
                 $FECHA_AGREGADO=$_POST["FECHA_AGREGADO"];
                     $Foto_producto= addslashes(file_get_contents($_FILES['Foto_producto']['tmp_name']));
                 
                $insert="INSERT INTO producto(ID_PRODUCTO, PRECIO, NOMBRE_DEL_PRODUCTO, FECHA_AGREGADO,Foto_producto)VALUES ('$ID_PRODUCTO','$PRECIO','$NOMBRE_DEL_PRODUCTO','$FECHA_AGREGADO','$Foto_producto')";

if($mysqli ->query($insert)) {?>
<script>
    alert("agregado con exito")
    window.location="../vista/html/principal_MS.html"
</script>
<?php
} else{?>
<script>
    alert("no se guardo el producto")
    window.location="../VISTA/HTML/Registrar_producto.html"
</script>
<?php
}
